import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'features/inventory/screens/inventory_screen.dart';
import 'features/billing/screens/billing_screen.dart';
import 'features/bills/screens/bills_history_screen.dart';

// ─── Nav index provider ───────────────────────────────────
final navIndexProvider = StateProvider<int>((ref) => 0);

void main() {
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'POS App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF2563EB),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: const MainShell(),
    );
  }
}

// ─── MAIN SHELL ───────────────────────────────────────────
class MainShell extends ConsumerWidget {
  const MainShell({super.key});

  static const List<Widget> _screens = [
    DashboardScreen(),
    InventoryScreen(),
    BillingScreen(),
    BillsHistoryScreen(),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentIndex = ref.watch(navIndexProvider);

    return Scaffold(
      body: _screens[currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (index) =>
            ref.read(navIndexProvider.notifier).state = index,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Inventory'),
          NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'Billing'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Bills'),
        ],
      ),
    );
  }
}

// ─── DASHBOARD ───────────────────────────────────────────
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('POS Dashboard')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Quick Actions',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              children: [
                _DashboardCard(
                  icon: Icons.qr_code_scanner,
                  label: 'Start Billing',
                  color: const Color(0xFF2563EB),
                  onTap: () => ref.read(navIndexProvider.notifier).state = 2,
                ),
                const SizedBox(width: 12),
                _DashboardCard(
                  icon: Icons.add_box,
                  label: 'Add Product',
                  color: const Color(0xFF16A34A),
                  onTap: () => ref.read(navIndexProvider.notifier).state = 1,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _DashboardCard(
                  icon: Icons.receipt_long,
                  label: 'View Bills',
                  color: const Color(0xFF9333EA),
                  onTap: () => ref.read(navIndexProvider.notifier).state = 3,
                ),
                const SizedBox(width: 12),
                _DashboardCard(
                  icon: Icons.inventory_2,
                  label: 'Inventory',
                  color: const Color(0xFFEA580C),
                  onTap: () => ref.read(navIndexProvider.notifier).state = 1,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─── DASHBOARD CARD ───────────────────────────────────────
class _DashboardCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _DashboardCard({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 110,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 36),
              const SizedBox(height: 8),
              Text(label,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14)),
            ],
          ),
        ),
      ),
    );
  }
}