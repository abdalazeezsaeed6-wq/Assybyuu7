import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../models/bill.dart';
import 'package:intl/intl.dart';

class PdfService {
  static Future<void> generateAndOpenBill(Bill bill) async {
    final pdf = pw.Document();

    final dateStr = DateFormat('dd MMM yyyy, hh:mm a').format(bill.createdAt);

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // ── Header ────────────────────────────────
              pw.Center(
                child: pw.Column(
                  children: [
                    pw.Text(
                      'MY SHOP',
                      style: pw.TextStyle(
                        fontSize: 28,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Text(
                      'Point of Sale Receipt',
                      style: pw.TextStyle(
                          fontSize: 13, color: PdfColors.grey700),
                    ),
                    pw.SizedBox(height: 4),
                    pw.Text(
                      dateStr,
                      style: pw.TextStyle(
                          fontSize: 11, color: PdfColors.grey600),
                    ),
                  ],
                ),
              ),

              pw.SizedBox(height: 8),
              pw.Divider(thickness: 1.5),
              pw.SizedBox(height: 4),

              // ── Bill number ───────────────────────────
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('Bill No:',
                      style: pw.TextStyle(
                          fontSize: 11, color: PdfColors.grey700)),
                  pw.Text(bill.billNumber,
                      style: pw.TextStyle(
                          fontSize: 11, fontWeight: pw.FontWeight.bold)),
                ],
              ),

              pw.SizedBox(height: 12),
              pw.Divider(),
              pw.SizedBox(height: 6),

              // ── Column headers ────────────────────────
              pw.Row(
                children: [
                  pw.Expanded(
                    flex: 4,
                    child: pw.Text('ITEM',
                        style: pw.TextStyle(
                            fontSize: 10,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.grey700)),
                  ),
                  pw.Expanded(
                    flex: 1,
                    child: pw.Text('QTY',
                        textAlign: pw.TextAlign.center,
                        style: pw.TextStyle(
                            fontSize: 10,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.grey700)),
                  ),
                  pw.Expanded(
                    flex: 2,
                    child: pw.Text('PRICE',
                        textAlign: pw.TextAlign.right,
                        style: pw.TextStyle(
                            fontSize: 10,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.grey700)),
                  ),
                  pw.Expanded(
                    flex: 2,
                    child: pw.Text('TOTAL',
                        textAlign: pw.TextAlign.right,
                        style: pw.TextStyle(
                            fontSize: 10,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.grey700)),
                  ),
                ],
              ),

              pw.SizedBox(height: 6),
              pw.Divider(thickness: 0.5),

              // ── Items ─────────────────────────────────
              ...bill.items.map(
                (item) => pw.Padding(
                  padding: const pw.EdgeInsets.symmetric(vertical: 5),
                  child: pw.Row(
                    children: [
                      pw.Expanded(
                        flex: 4,
                        child: pw.Text(item.name,
                            style: const pw.TextStyle(fontSize: 11)),
                      ),
                      pw.Expanded(
                        flex: 1,
                        child: pw.Text('${item.quantity}',
                            textAlign: pw.TextAlign.center,
                            style: const pw.TextStyle(fontSize: 11)),
                      ),
                      pw.Expanded(
                        flex: 2,
                        child: pw.Text(
                            'Rs.${item.price.toStringAsFixed(2)}',
                            textAlign: pw.TextAlign.right,
                            style: const pw.TextStyle(fontSize: 11)),
                      ),
                      pw.Expanded(
                        flex: 2,
                        child: pw.Text(
                            'Rs.${item.subtotal.toStringAsFixed(2)}',
                            textAlign: pw.TextAlign.right,
                            style: pw.TextStyle(
                                fontSize: 11,
                                fontWeight: pw.FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              ),

              pw.SizedBox(height: 6),
              pw.Divider(thickness: 1),
              pw.SizedBox(height: 8),

              // ── Total ─────────────────────────────────
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text('TOTAL AMOUNT',
                      style: pw.TextStyle(
                          fontSize: 14, fontWeight: pw.FontWeight.bold)),
                  pw.Text('Rs. ${bill.totalAmount.toStringAsFixed(2)}',
                      style: pw.TextStyle(
                          fontSize: 16, fontWeight: pw.FontWeight.bold)),
                ],
              ),

              pw.SizedBox(height: 24),
              pw.Divider(thickness: 0.5),
              pw.SizedBox(height: 12),

              // ── Footer ────────────────────────────────
              pw.Center(
                child: pw.Column(
                  children: [
                    pw.Text('Thank you for your purchase!',
                        style: pw.TextStyle(
                            fontSize: 12,
                            fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 4),
                    pw.Text('Please come again',
                        style: pw.TextStyle(
                            fontSize: 11, color: PdfColors.grey600)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );

    // Open print/share dialog
    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
      name: '${bill.billNumber}.pdf',
    );
  }
}