class Product {
  final int? id;
  final String barcode;
  final String name;
  final double price;
  int quantity;

  Product({
    this.id,
    required this.barcode,
    required this.name,
    required this.price,
    required this.quantity,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'barcode': barcode,
      'name': name,
      'price': price,
      'quantity': quantity,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'],
      barcode: map['barcode'],
      name: map['name'],
      price: map['price'].toDouble(),
      quantity: map['quantity'],
    );
  }

  Product copyWith({int? id, String? barcode, String? name, double? price, int? quantity}) {
    return Product(
      id: id ?? this.id,
      barcode: barcode ?? this.barcode,
      name: name ?? this.name,
      price: price ?? this.price,
      quantity: quantity ?? this.quantity,
    );
  }
}