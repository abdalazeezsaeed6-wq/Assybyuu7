class BillItem {
  final String barcode;
  final String name;
  final double price;
  int quantity;

  BillItem({
    required this.barcode,
    required this.name,
    required this.price,
    required this.quantity,
  });

  double get subtotal => price * quantity;

  Map<String, dynamic> toMap() {
    return {
      'barcode': barcode,
      'name': name,
      'price': price,
      'quantity': quantity,
    };
  }

  factory BillItem.fromMap(Map<String, dynamic> map) {
    return BillItem(
      barcode: map['barcode'],
      name: map['name'],
      price: map['price'].toDouble(),
      quantity: map['quantity'],
    );
  }
}

class Bill {
  final int? id;
  final String billNumber;
  final List<BillItem> items;
  final double totalAmount;
  final DateTime createdAt;

  Bill({
    this.id,
    required this.billNumber,
    required this.items,
    required this.totalAmount,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'bill_number': billNumber,
      'items': items.map((e) => e.toMap()).toList().toString(), // stored as string, parsed back
      'total_amount': totalAmount,
      'created_at': createdAt.toIso8601String(),
    };
  }
}