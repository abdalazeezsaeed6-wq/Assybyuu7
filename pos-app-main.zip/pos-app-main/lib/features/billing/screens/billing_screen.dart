import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../providers/billing_provider.dart';
import '../../inventory/providers/inventory_provider.dart';
import '../../../core/database/database_helper.dart';
import '../../../models/bill.dart';
import '../../../shared/services/pdf_service.dart';
import 'package:uuid/uuid.dart';

class BillingScreen extends ConsumerStatefulWidget {
  const BillingScreen({super.key});

  @override
  ConsumerState<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends ConsumerState<BillingScreen> {
  bool _isScanning = false;
  bool _isProcessing = false;
  MobileScannerController? _scannerController;
  String? _lastScanned;

  @override
  void dispose() {
    _scannerController?.dispose();
    super.dispose();
  }

  void _toggleScanner() {
    if (_isScanning) {
      _scannerController?.dispose();
      _scannerController = null;
      setState(() => _isScanning = false);
    } else {
      _scannerController = MobileScannerController(
        detectionSpeed: DetectionSpeed.noDuplicates,
        facing: CameraFacing.back,
        torchEnabled: false,
      );
      setState(() => _isScanning = true);
    }
  }

  Future<void> _onBarcodeDetected(BarcodeCapture capture) async {
    final barcode = capture.barcodes.firstOrNull?.rawValue;
    if (barcode == null || barcode == _lastScanned || _isProcessing) return;

    setState(() {
      _isProcessing = true;
      _lastScanned = barcode;
    });

    final product = await ref
        .read(inventoryProvider.notifier)
        .getByBarcode(barcode);

    if (!mounted) return;

    if (product == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Product not found for barcode: $barcode'),
          backgroundColor: Colors.red,
        ),
      );
    } else if (product.quantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${product.name} is out of stock!'),
          backgroundColor: Colors.orange,
        ),
      );
    } else {
      // addItem now returns false if stock limit reached
      final added = await ref.read(cartProvider.notifier).addItem(product);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          added
              ? SnackBar(
                  content: Text('${product.name} added to cart'),
                  backgroundColor: Colors.green,
                  duration: const Duration(seconds: 1),
                )
              : SnackBar(
                  content: Text(
                    '${product.name} — max stock reached (${product.quantity})',
                  ),
                  backgroundColor: Colors.orange,
                  duration: const Duration(seconds: 2),
                ),
        );
      }
    }

    await Future.delayed(const Duration(seconds: 2));
    if (mounted) {
      setState(() {
        _isProcessing = false;
        _lastScanned = null;
      });
    }
  }

  Future<void> _checkout() async {
    final items = ref.read(cartProvider);
    if (items.isEmpty) return;

    final total = ref.read(cartTotalProvider);
    final billNumber =
        'BILL-${const Uuid().v4().substring(0, 8).toUpperCase()}';

    final bill = Bill(
      billNumber: billNumber,
      items: items,
      totalAmount: total,
      createdAt: DateTime.now(),
    );

    // Save bill to DB
    await DatabaseHelper.instance.insertBill(bill);

    // Deduct stock
    for (final item in items) {
      final product = await DatabaseHelper.instance.getProductByBarcode(
        item.barcode,
      );
      if (product != null) {
        await DatabaseHelper.instance.updateProductQuantity(
          item.barcode,
          product.quantity - item.quantity,
        );
      }
    }

    // Refresh inventory
    ref.invalidate(inventoryProvider);

    // Generate PDF
    await PdfService.generateAndOpenBill(bill);

    // Clear cart
    ref.read(cartProvider.notifier).clearCart();

    if (mounted) {
      // close scanner if open
      if (_isScanning) {
        _scannerController?.dispose();
        _scannerController = null;
        setState(() => _isScanning = false);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bill generated successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cartItems = ref.watch(cartProvider);
    final total = ref.watch(cartTotalProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Billing'),
        actions: [
          if (cartItems.isNotEmpty)
            TextButton.icon(
              onPressed: () => ref.read(cartProvider.notifier).clearCart(),
              icon: const Icon(Icons.clear_all, color: Colors.white),
              label: const Text('Clear', style: TextStyle(color: Colors.white)),
            ),
        ],
      ),
      body: Column(
        children: [
          // ── Scanner toggle ─────────────────────────────
          Padding(
            padding: const EdgeInsets.all(16),
            child: GestureDetector(
              onTap: _toggleScanner,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                height: _isScanning ? 220 : 60,
                decoration: BoxDecoration(
                  color: _isScanning ? Colors.black : const Color(0xFF2563EB),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: _isScanning
                    ? Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: _scannerController == null
                                ? const Center(
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                    ),
                                  )
                                : MobileScanner(
                                    controller: _scannerController!,
                                    onDetect: _onBarcodeDetected,
                                    errorBuilder: (context, error) {
                                      return Container(
                                        color: Colors.black,
                                        child: Center(
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              const Icon(
                                                Icons.error,
                                                color: Colors.red,
                                                size: 40,
                                              ),
                                              const SizedBox(height: 8),
                                              Text(
                                                error.errorDetails?.message ??
                                                    'Camera error. Check permissions.',
                                                style: const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 12,
                                                ),
                                                textAlign: TextAlign.center,
                                              ),
                                              const SizedBox(height: 12),
                                              ElevatedButton(
                                                onPressed: () {
                                                  _scannerController?.dispose();
                                                  _scannerController =
                                                      MobileScannerController(
                                                        detectionSpeed:
                                                            DetectionSpeed
                                                                .noDuplicates,
                                                        facing:
                                                            CameraFacing.back,
                                                      );
                                                  setState(() {});
                                                },
                                                child: const Text('Retry'),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                          ),
                          Positioned(
                            top: 8,
                            right: 8,
                            child: GestureDetector(
                              onTap: _toggleScanner,
                              child: const CircleAvatar(
                                backgroundColor: Colors.black54,
                                child: Icon(Icons.close, color: Colors.white),
                              ),
                            ),
                          ),
                          if (_isProcessing)
                            const Center(
                              child: CircularProgressIndicator(
                                color: Colors.white,
                              ),
                            ),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.qr_code_scanner, color: Colors.white),
                          SizedBox(width: 8),
                          Text(
                            'Tap to Scan Barcode',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),

          // ── Cart items ─────────────────────────────────
          Expanded(
            child: cartItems.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.shopping_cart_outlined,
                          size: 64,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 12),
                        Text(
                          'Cart is empty',
                          style: TextStyle(color: Colors.grey, fontSize: 16),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Scan a product to add it',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: cartItems.length,
                    // ← fixed: use two different names
                    separatorBuilder: (context, index) =>
                        const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final item = cartItems[index];
                      return _CartItemCard(item: item);
                    },
                  ),
          ),

          // ── Total & Checkout ───────────────────────────
          if (cartItems.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.08),
                    blurRadius: 10,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Total',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Rs. ${total.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2563EB),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF16A34A),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: _checkout,
                      icon: const Icon(Icons.receipt),
                      label: const Text(
                        'Checkout & Generate Bill',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ── Cart Item Card ─────────────────────────────────────────
class _CartItemCard extends ConsumerWidget {
  final BillItem item;
  const _CartItemCard({required this.item});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.read(cartProvider.notifier);
    final stock = cart.availableStock(item.barcode);
    final inCart = cart.inCartQty(item.barcode);
    final atMax = inCart >= stock;

    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.name,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text('Rs. ${item.price.toStringAsFixed(2)} each',
                      style:
                          const TextStyle(color: Colors.grey, fontSize: 12)),
                  // stock indicator
                  Text(
                    'Stock: $stock  |  In cart: $inCart',
                    style: TextStyle(
                      fontSize: 11,
                      color: atMax ? Colors.orange : Colors.grey,
                      fontWeight:
                          atMax ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ],
              ),
            ),
            // Qty controls
            Row(
              children: [
                IconButton(
                  onPressed: () => ref
                      .read(cartProvider.notifier)
                      .decrementItem(item.barcode),
                  icon: const Icon(Icons.remove_circle_outline),
                  color: Colors.red,
                ),
                Text('${item.quantity}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16)),
                IconButton(
                  // grey out + disable when at stock limit
                  onPressed: atMax
                      ? null
                      : () {
                          final ok = ref
                              .read(cartProvider.notifier)
                              .incrementItem(item.barcode);
                          if (!ok) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                    '${item.name} — only $stock in stock'),
                                backgroundColor: Colors.orange,
                                duration: const Duration(seconds: 2),
                              ),
                            );
                          }
                        },
                  icon: Icon(
                    Icons.add_circle_outline,
                    color: atMax ? Colors.grey : Colors.green,
                  ),
                ),
              ],
            ),
            // Subtotal
            SizedBox(
              width: 75,
              child: Text(
                'Rs. ${item.subtotal.toStringAsFixed(2)}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2563EB)),
                textAlign: TextAlign.right,
              ),
            ),
          ],
        ),
      ),
    );
  }
}