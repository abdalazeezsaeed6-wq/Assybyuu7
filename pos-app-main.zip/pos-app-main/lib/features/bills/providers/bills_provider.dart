import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/database/database_helper.dart';
import '../../../models/bill.dart';

final billsProvider =
    AsyncNotifierProvider<BillsNotifier, List<Bill>>(BillsNotifier.new);

class BillsNotifier extends AsyncNotifier<List<Bill>> {
  @override
  Future<List<Bill>> build() async {
    return await DatabaseHelper.instance.getAllBills();
  }

  Future<void> deleteBill(int id) async {
    await DatabaseHelper.instance.deleteBill(id);
    ref.invalidateSelf();
  }

  void refresh() => ref.invalidateSelf();
}