import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/database/database_helper.dart';
import '../../../models/product.dart';

final inventoryProvider =
    AsyncNotifierProvider<InventoryNotifier, List<Product>>(
        InventoryNotifier.new);

class InventoryNotifier extends AsyncNotifier<List<Product>> {
  @override
  Future<List<Product>> build() async {
    return await DatabaseHelper.instance.getAllProducts();
  }

  Future<void> addProduct(Product product) async {
    await DatabaseHelper.instance.insertProduct(product);
    ref.invalidateSelf();
  }

  Future<void> updateProduct(Product product) async {
    await DatabaseHelper.instance.updateProduct(product);
    ref.invalidateSelf();
  }

  Future<void> deleteProduct(int id) async {
    await DatabaseHelper.instance.deleteProduct(id);
    ref.invalidateSelf();
  }

  Future<Product?> getByBarcode(String barcode) async {
    return await DatabaseHelper.instance.getProductByBarcode(barcode);
  }
}